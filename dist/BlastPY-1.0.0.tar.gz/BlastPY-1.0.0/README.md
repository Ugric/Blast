# BlastAI
a machine learning framework by W̷̛͒i̶̓͗l̷͗̌ľ̶͘

# Licence
This project is licensed under the terms of the MIT license.